#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "shader.h"
#include <cmath>
#include<time.h> 

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
glm::mat4 change(GLFWwindow* window, int choose);

unsigned int SCR_WIDTH = 800;
unsigned int SCR_HEIGHT = 600;
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;
float pitch = 0.0f;
float yaw = -90.0f;
float lastX = 0, lastY = 0;
bool firstMouse = true;
int sign = 0;
glm::vec3 positions[10];
glm::vec3 positions2[10];
glm::vec3 positions3[10];
float cdegrees[10];
float cudegrees[10];
float pdegrees[10];
float cdelta[10];
float cudelta[10];
float pdelta[10];
int choose = -1;
int itemc = -1;
int itemcu = -1;
int itemp = -1;
int t = -1;
float degree = 1.0f,degree2=1.0f,degree3=1.0f;
float delta = 0.0f, delta2 = 0.0f, delta3 = 0.0f;
int in = 0;
int in2 = 0;
int in3 = 0;

int main()
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif


    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    // glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }


    glEnable(GL_DEPTH_TEST);


    Shader ourShader("6.3.coordinate_systems.vs", "6.3.coordinate_systems.fs");

    float vertices1[] = {

0.0f, 0.5f, 0.0f,0.0f,0.0f,
-0.5f, -0.5f, 0.5f,1.0f,0.0f,
0.5f, -0.5f, 0.5f,0.0f,1.0f,


0.0f, 0.5f, 0.0f,0.0f,0.0f,
0.5f, -0.5f, -0.5f,1.0f,0.0f,
-0.5f, -0.5f, -0.5f,0.0f,1.0f,


0.0f, 0.5f, 0.0f,0.0f,0.0f,
-0.5f,-0.5f,-0.5f,1.0f,0.0f,
-0.5f,-0.5f, 0.5f,0.0f,1.0f,


0.0f, 0.5f, 0.0f,0.0f,0.0f,
0.5f, -0.5f, 0.5f,1.0f,0.0f,
0.5f, -0.5f, -0.5f,0.0f,1.0f

    };
    float vertices2[] = {
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,

    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,

    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,

    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f
    };
    float vertices3[] = {
      -0.5f, -0.5f, 0.5f,0.0f,0.0f,
     0.5f, -0.5f, 0.5f,1.0f,0.0f,
     0.0f,  0.5f, 0.5f,0.0f,1.0f,

     -0.5f, -0.5f, 0.0f,0.0f,0.0f,
     0.5f, -0.5f, 0.0f,1.0f,0.0f,
     0.0f,  0.5f, 0.0f,0.0f,1.0f,

    -0.5f, -0.5f, 0.5f,0.0f,0.0f,
    -0.5f, -0.5f, 0.0f,1.0f,0.0f,
    0.5f, -0.5f, 0.5f,1.0f,1.0f,
    -0.5f, -0.5f, 0.0f,0.0f,1.0f,
    0.5f, -0.5f, 0.5f,1.0f,0.0f,
    0.5f, -0.5f, 0.0f,0.0f,1.0f,

    0.5f, -0.5f, 0.0f,1.0f,0.0f,
    0.5f, -0.5f, 0.5f,0.0f,0.0f,
    0.0f,  0.5f, 0.5f,0.0f,1.0f,
    0.0f,  0.5f, 0.5f,0.0f,0.0f,
    0.0f,  0.5f, 0.0f,0.0f,1.0f,
    0.5f, -0.5f, 0.0f,1.0f,0.0f,

    0.0f,  0.5f, 0.0f,0.0f,1.0f,
    0.0f,  0.5f, 0.5f,0.0f,0.0f,
    -0.5f, -0.5f, 0.0f,1.0f,0.0f,
    -0.5f, -0.5f, 0.0f,0.0f,0.0f,
    -0.5f, -0.5f, 0.5f,1.0f,0.0f,
     0.0f,  0.5f, 0.5f,0.0f,1.0f


    };
  
    unsigned int VBO1, VAO1, VBO2, VAO2, VBO3, VAO3;
    glGenVertexArrays(1, &VAO1);
    glGenBuffers(1, &VBO1);
    glBindVertexArray(VAO1);
    glBindBuffer(GL_ARRAY_BUFFER, VBO1);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices1), vertices1, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);


    glGenVertexArrays(1, &VAO2);
    glGenBuffers(1, &VBO2);
    glBindVertexArray(VAO2);
    glBindBuffer(GL_ARRAY_BUFFER, VBO2);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);


    glGenVertexArrays(1, &VAO3);
    glGenBuffers(1, &VBO3);
    glBindVertexArray(VAO3);
    glBindBuffer(GL_ARRAY_BUFFER, VBO3);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices3), vertices3, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // load and create a texture 
    // -------------------------
    unsigned int texture1;
    // texture 1
    // ---------
    glGenTextures(1, &texture1);
    glBindTexture(GL_TEXTURE_2D, texture1);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    int width, height, nrChannels;
    stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
    unsigned char* data = stbi_load("library.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);
    ourShader.use();
    ourShader.setInt("texture1", 0);

    while (!glfwWindowShouldClose(window))
    {
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        processInput(window);

        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // also clear the depth buffer now!

         // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture1);

        // activate shader
        ourShader.use();

        // create transformations
        glm::mat4 view = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        glm::mat4 projection = glm::mat4(1.0f);
        projection = glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        // pass transformation matrices to the shader
        ourShader.setMat4("projection", projection); // note: currently we set the projection matrix each frame, but since the projection matrix rarely changes it's often best practice to set it outside the main loop only once.
        ourShader.setMat4("view", view);

        glBindVertexArray(VAO1);
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
        float angle = 0.0f;
        model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
        model = glm::scale(model, glm::vec3(1.0, 1.0, 1.0));
        ourShader.setMat4("model", model);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glBindVertexArray(VAO2);
        glm::mat4 model2 = glm::mat4(1.0f);
        model2 = glm::translate(model2, glm::vec3(1.5f, 0.2f, -1.5f));
        float angle2 = 0.0f;
        model2 = glm::rotate(model2, glm::radians(angle2), glm::vec3(1.0f, 0.3f, 0.5f));
        model2 = glm::scale(model2, glm::vec3(1.0, 1.0, 1.0));
        ourShader.setMat4("model", model2);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glBindVertexArray(VAO3);
        glm::mat4 model3 = glm::mat4(1.0f);
        model3 = glm::translate(model3, glm::vec3(-1.5f, 0.2f, -1.5f));
        float angle3 = 0.0f;
        model3 = glm::rotate(model3, glm::radians(angle3), glm::vec3(1.0f, 0.3f, 0.5f));
        model3 = glm::scale(model3, glm::vec3(1.0, 1.0, 1.0));
        ourShader.setMat4("model", model3);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        if (choose == 1) {
            glBindVertexArray(VAO1);
            model = glm::mat4(1.0f);
            model = change(window, choose);
            if (t == 0 or t == 3 or t==5 or t==7) {
                model = glm::scale(model, glm::vec3((degree), 1.0, 1.0));
                model = glm::rotate(model, delta, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            model = glm::translate(model, positions[itemc]);
            ourShader.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            if (itemc > 0) {
                int i = 0;
                for (i = 0; i < itemc; i++) {
                    glBindVertexArray(VAO1);
                    model = glm::mat4(1.0f);
                    model = glm::scale(model, glm::vec3(cdegrees[i], 1.0, 1.0));
                    model = glm::rotate(model, cdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                    model = glm::translate(model, positions[i]);
                    ourShader.setMat4("model", model);
                    glDrawArrays(GL_TRIANGLES, 0, 36);
                }
            }
            int i = 0;
            for (i = 0; i <= itemcu; i++) {
                glBindVertexArray(VAO2);
                model2 = glm::mat4(1.0f);
                model2 = glm::scale(model2, glm::vec3(cudegrees[i], 1.0f, 1.0f));
                model2 = glm::rotate(model2, cudelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model2 = glm::translate(model2, positions2[i]);
                ourShader.setMat4("model", model2);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }
            for (i = 0; i <= itemp; i++) {
                glBindVertexArray(VAO3);
                model3 = glm::mat4(1.0f);
                model3 = glm::scale(model3, glm::vec3(pdegrees[i], 1.0f, 1.0f));
                model3 = glm::rotate(model3, pdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model3 = glm::translate(model3, positions3[i]);
                ourShader.setMat4("model", model3);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }

        }
        
        if (choose == 2) {
            glBindVertexArray(VAO2);
            model2 = glm::mat4(1.0f);
            model2 = change(window, choose);
            if (t == 0 or t == 3 or t==5 or t==7) {
                model2 = glm::scale(model2, glm::vec3(degree2, 1.0f, 1.0f));
                model2 = glm::rotate(model2, delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            model2 = glm::translate(model2, positions2[itemcu]);
            ourShader.setMat4("model", model2);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            if (itemcu > 0) {
                int i = 0;
                for (i = 0; i < itemcu; i++) {
                    glBindVertexArray(VAO2);
                    model2 = glm::mat4(1.0f);
                    model2 = glm::scale(model2,glm::vec3(cudegrees[i],1.0f,1.0f));
                    model2 = glm::rotate(model2, cudelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                    model2 = glm::translate(model2, positions2[i]);
                    ourShader.setMat4("model", model2);
                    glDrawArrays(GL_TRIANGLES, 0, 36);
                }
            }
            int i = 0;
            for (i = 0; i <= itemc; i++) {
                glBindVertexArray(VAO1);
                model = glm::mat4(1.0f);
                model = glm::scale(model, glm::vec3(cdegrees[i], 1.0, 1.0));
                model = glm::rotate(model, cdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model = glm::translate(model, positions[i]);
                ourShader.setMat4("model", model);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }
            for (i = 0; i <= itemp; i++) {
                glBindVertexArray(VAO3);
                model3 = glm::mat4(1.0f);
                model3 = glm::scale(model3, glm::vec3(pdegrees[i], 1.0f, 1.0f));
                model3 = glm::rotate(model3, pdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model3 = glm::translate(model3, positions3[i]);
                ourShader.setMat4("model", model3);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }
        }
        
        if (choose == 3) {
            glBindVertexArray(VAO3);
            model3 = glm::mat4(1.0f);
            model3 = change(window, choose);
            if (t == 0 or t == 3 or t==5 or t==7) {
                model3 = glm::scale(model3, glm::vec3(degree3, 1.0f, 1.0f));
                model3 = glm::rotate(model3, delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            model3 = glm::translate(model3, positions3[itemp]);
            ourShader.setMat4("model", model3);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            if (itemp > 0) {
                int i = 0;
                for (i = 0; i < itemp; i++) {
                    glBindVertexArray(VAO3);
                    model3 = glm::mat4(1.0f);
                    model3 = glm::scale(model3, glm::vec3(pdegrees[i], 1.0f, 1.0f));
                    model3 = glm::rotate(model3, pdelta[i],glm::vec3(0.0f, 1.0f, 0.0f));
                    model3 = glm::translate(model3, positions3[i]);
                    ourShader.setMat4("model", model3);
                    glDrawArrays(GL_TRIANGLES, 0, 36);
                }
            }
            int i = 0;
            for (i = 0; i <= itemc; i++) {
                glBindVertexArray(VAO1);
                model = glm::mat4(1.0f);
                model = glm::scale(model, glm::vec3(cdegrees[i], 1.0, 1.0));
                model = glm::rotate(model, cdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model = glm::translate(model, positions[i]);
                ourShader.setMat4("model", model);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }
            for (i = 0; i <= itemcu; i++) {
                glBindVertexArray(VAO2);
                model2 = glm::mat4(1.0f);
                model2 = glm::scale(model2, glm::vec3(cudegrees[i], 1.0f, 1.0f));
                model2 = glm::rotate(model2, cudelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model2 = glm::translate(model2, positions2[i]);
                ourShader.setMat4("model", model2);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }
        }
        
        if (choose == 0) {
            int i = 0;
            for (i = 0; i <= itemc; i++) {
                glBindVertexArray(VAO1);
                model = glm::mat4(1.0f);
                model = glm::scale(model, glm::vec3(cdegrees[i], 1.0, 1.0));
                model = glm::rotate(model, cdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model = glm::translate(model, positions[i]);
                ourShader.setMat4("model", model);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }

            for (i = 0; i <= itemcu; i++) {
                glBindVertexArray(VAO2);
                model2 = glm::mat4(1.0f);
                model2 = glm::scale(model2, glm::vec3(cudegrees[i], 1.0f, 1.0f));
                model2 = glm::rotate(model2, cudelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model2 = glm::translate(model2, positions2[i]);
                ourShader.setMat4("model", model2);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }

            for (i = 0; i <= itemp; i++) {
                glBindVertexArray(VAO3);
                model3 = glm::mat4(1.0f);
                model3 = glm::scale(model3, glm::vec3(pdegrees[i], 1.0f, 1.0f));
                model3 = glm::rotate(model3, pdelta[i], glm::vec3(0.0f, 1.0f, 0.0f));
                model3 = glm::translate(model3, positions3[i]);
                ourShader.setMat4("model", model3);
                glDrawArrays(GL_TRIANGLES, 0, 36);
            }



        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO1);
    glDeleteBuffers(1, &VBO1);
    glDeleteVertexArrays(1, &VAO2);
    glDeleteBuffers(1, &VBO2);
    glDeleteVertexArrays(1, &VAO3);
    glDeleteBuffers(1, &VBO3);


    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}

void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    float cameraSpeed = 2.5 * deltaTime;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
        if (sign == 0)
            sign = 1;
        else
            sign = 0;
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        choose = 1;
        in = 1;
    }
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_RELEASE and in == 1) {
        itemc = itemc + 1;
        degree = 1.0f;
        delta = 0.0f;
        positions[itemc] = cameraFront + cameraPos;
        in = 0;
    }

    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS) {
        choose = 2;
        in2 = 1;
    }
    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_RELEASE and in2 == 1) {
        itemcu = itemcu + 1;
        degree2 = 1.0f;
        delta2 = 0.0f;
        positions2[itemcu] = cameraFront+cameraPos;
        in2 = 0;
    }

    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
        choose = 3;
        in3 = 1;
    }
    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_RELEASE and in3 == 1) {
        itemp = itemp + 1;
        degree3 = 1.0f;
        delta3 = 0.0f;
        positions3[itemp] = cameraFront + cameraPos;
        in3 = 0;
    }


    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        if (choose == 1) {
            cdelta[itemc] = delta;
            cdegrees[itemc] = degree;

        }
        if (choose == 2) {
            cudelta[itemcu] = delta2;
            cudegrees[itemcu] = degree2;
        }
        if (choose == 3) {
            pdelta[itemp] = delta3;
            pdegrees[itemp] = degree3;
        }
        choose = 0;
    }
}
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
    SCR_HEIGHT = height;
    SCR_WIDTH = width;
}
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    if (sign == 0)
        pitch += yoffset;
    else
        pitch -= yoffset;

    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 direction;
    direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    direction.y = sin(glm::radians(pitch));
    direction.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(direction);
}
glm::mat4 change(GLFWwindow* window, int choose) {
    glm::mat4 mod = glm::mat4(1.0f);
    if (choose == 1) {
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
            delta = delta + 0.002;
            mod = glm::scale(mod, glm::vec3(degree, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 1;
        }
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_RELEASE and t == 1) {
            t = 0;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            delta = delta - 0.002;
            mod = glm::scale(mod, glm::vec3(degree, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 2;
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_RELEASE and t == 2) {
            t = 3;
        }
        
        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) {
            degree += 0.002;
            mod = glm::scale(mod, glm::vec3(degree, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 4;
        }
        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_RELEASE and t == 4) {
            t = 5;
        }

        if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS) {
            if((degree-0.002)>=0)
                    degree -= 0.002;
            mod = glm::scale(mod, glm::vec3(degree, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 6;
        }
        if (glfwGetKey(window, GLFW_KEY_J) == GLFW_RELEASE and t == 6) {
            t = 7;
        }


    }
    if (choose == 2) {
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
            delta2 = delta2 +0.002;
            mod = glm::scale(mod, glm::vec3(degree2, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 1;
        }
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_RELEASE and t == 1) {
            t = 0;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            delta2 = delta2 - 0.002;
            mod = glm::scale(mod, glm::vec3(degree2, 1.0f, 1.0f));
            mod = glm::rotate(mod,delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 2;
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_RELEASE and t == 2) {
            t = 3;
        }

        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) {
            degree2 += 0.002;
            mod = glm::scale(mod, glm::vec3(degree2, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 4;
        }
        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_RELEASE and t == 4) {
            t = 5;
        }

        if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS) {
            if ((degree2 - 0.002) >= 0)
                degree2 -= 0.002;
            mod = glm::scale(mod, glm::vec3(degree2, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta2,glm::vec3(0.0f, 1.0f, 0.0f));
            t = 6;
        }
        if (glfwGetKey(window, GLFW_KEY_J) == GLFW_RELEASE and t == 6) {
            t = 7;
        }

    }
    if (choose == 3) {
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
            delta3 = delta3 + 0.002;
            mod = glm::scale(mod, glm::vec3(degree3, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 1;
        }
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_RELEASE and t == 1) {
            t = 0;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            delta3 = delta3 - 0.002;
            mod = glm::scale(mod, glm::vec3(degree3, 1.0f, 1.0f));
            mod = glm::rotate(mod,delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 2;
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_RELEASE and t == 2) {
            t = 3;
        }

        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) {
            degree3 += 0.002;
            mod = glm::scale(mod, glm::vec3(degree3, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 4;
        }
        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_RELEASE and t == 4) {
            t = 5;
        }

        if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS) {
            if ((degree3 - 0.002) >= 0)
                degree3 -= 0.002;
            mod = glm::scale(mod, glm::vec3(degree3, 1.0f, 1.0f));
            mod = glm::rotate(mod, delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            t = 6;
        }
        if (glfwGetKey(window, GLFW_KEY_J) == GLFW_RELEASE and t == 6) {
            t = 7;
        }

    }
    return mod;

}