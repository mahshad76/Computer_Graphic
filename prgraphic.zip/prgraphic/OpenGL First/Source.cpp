#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <string>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "shader.h"
#include <cmath>
#include<time.h> 


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
glm::mat4 change(GLFWwindow* window, int choose);


unsigned int SCR_WIDTH = 800;
unsigned int SCR_HEIGHT = 600;
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;
float pitch = 0.0f;
float yaw = -90.0f;
float lastX = 0, lastY = 0;
bool firstMouse = true;
int sign = 0, choose = 0, t = -1, direction1 = 0, direction2 = 0, direction3 = 0,select1=0,select2=0,select3=0,
dir1=0,dir2=0,dir3=0;
glm::mat4 model, model2, model3;
float delta = 0.0f, delta2 = 0.0f, delta3 = 0.0f,degree=0.0f,degree2=0.0f,degree3=0.0f;
float ee = 0.0f;

int main()
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif


    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }


    glEnable(GL_DEPTH_TEST);


    Shader ourShader("6.3.coordinate_systems.vs", "6.3.coordinate_systems.fs");

    float vertices1[] = {

0.0f, 0.5f, 0.0f,0.0f,0.0f,
-0.5f, -0.5f, 0.5f,1.0f,0.0f,
0.5f, -0.5f, 0.5f,0.0f,1.0f,


0.0f, 0.5f, 0.0f,0.0f,0.0f,
0.5f, -0.5f, -0.5f,1.0f,0.0f,
-0.5f, -0.5f, -0.5f,0.0f,1.0f,


0.0f, 0.5f, 0.0f,0.0f,0.0f,
-0.5f,-0.5f,-0.5f,1.0f,0.0f,
-0.5f,-0.5f, 0.5f,0.0f,1.0f,


0.0f, 0.5f, 0.0f,0.0f,0.0f,
0.5f, -0.5f, 0.5f,1.0f,0.0f,
0.5f, -0.5f, -0.5f,0.0f,1.0f

    };
    float vertices2[] = {
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,

    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,

    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,

    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f
    };
    float vertices3[] = {
      -0.5f, -0.5f, 0.5f,0.0f,0.0f,
     0.5f, -0.5f, 0.5f,1.0f,0.0f,
     0.0f,  0.5f, 0.5f,0.0f,1.0f,

     -0.5f, -0.5f, 0.0f,0.0f,0.0f,
     0.5f, -0.5f, 0.0f,1.0f,0.0f,
     0.0f,  0.5f, 0.0f,0.0f,1.0f,

    -0.5f, -0.5f, 0.5f,0.0f,0.0f,
    -0.5f, -0.5f, 0.0f,1.0f,0.0f,
    0.5f, -0.5f, 0.5f,1.0f,1.0f,
    -0.5f, -0.5f, 0.0f,0.0f,1.0f,
    0.5f, -0.5f, 0.5f,1.0f,0.0f,
    0.5f, -0.5f, 0.0f,0.0f,1.0f,

    0.5f, -0.5f, 0.0f,1.0f,0.0f,
    0.5f, -0.5f, 0.5f,0.0f,0.0f,
    0.0f,  0.5f, 0.5f,0.0f,1.0f,
    0.0f,  0.5f, 0.5f,0.0f,0.0f,
    0.0f,  0.5f, 0.0f,0.0f,1.0f,
    0.5f, -0.5f, 0.0f,1.0f,0.0f,

    0.0f,  0.5f, 0.0f,0.0f,1.0f,
    0.0f,  0.5f, 0.5f,0.0f,0.0f,
    -0.5f, -0.5f, 0.0f,1.0f,0.0f,
    -0.5f, -0.5f, 0.0f,0.0f,0.0f,
    -0.5f, -0.5f, 0.5f,1.0f,0.0f,
     0.0f,  0.5f, 0.5f,0.0f,1.0f


    };
    glm::vec3 cubePositions[] = {
    glm::vec3(-1.3f,  1.0f, -1.5f)
    };
    glm::vec3 pyramidPositins[] = {
         glm::vec3(1.7f, 1.0f, -1.5f)
    };
    glm::vec3 prismPositins[] = {
         glm::vec3(-1.3f,  -1.0f, -1.5f)
    };

    unsigned int VBO1, VAO1, VBO2, VAO2, VBO3, VAO3;
    glGenVertexArrays(1, &VAO1);
    glGenBuffers(1, &VBO1);
    glBindVertexArray(VAO1);
    glBindBuffer(GL_ARRAY_BUFFER, VBO1);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices1), vertices1, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);


    glGenVertexArrays(1, &VAO2);
    glGenBuffers(1, &VBO2);
    glBindVertexArray(VAO2);
    glBindBuffer(GL_ARRAY_BUFFER, VBO2);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);


    glGenVertexArrays(1, &VAO3);
    glGenBuffers(1, &VBO3);
    glBindVertexArray(VAO3);
    glBindBuffer(GL_ARRAY_BUFFER, VBO3);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices3), vertices3, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // load and create a texture 
    // -------------------------
    unsigned int texture1;
    // texture 1
    // ---------
    glGenTextures(1, &texture1);
    glBindTexture(GL_TEXTURE_2D, texture1);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    int width, height, nrChannels;
    stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
    unsigned char* data = stbi_load("library.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    // -------------------------------------------------------------------------------------------
    ourShader.use();
    ourShader.setInt("texture1", 0);


    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        processInput(window);
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // also clear the depth buffer now!

         // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture1);

        // activate shader
        ourShader.use();

        // create transformations
        glm::mat4 view = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        glm::mat4 projection = glm::mat4(1.0f);
        projection = glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        // pass transformation matrices to the shader
        ourShader.setMat4("projection", projection); // note: currently we set the projection matrix each frame, but since the projection matrix rarely changes it's often best practice to set it outside the main loop only once.
        ourShader.setMat4("view", view);
        
        if (choose == 1) {
            glBindVertexArray(VAO1);
            model = glm::mat4(1.0f);
            model = change(window, choose);
            if (t == 0 or t == 3) {
                model = glm::scale(model, glm::vec3((1.0 + degree), 1.0, 1.0));
                model = glm::rotate(model, float(direction1 * 1.0f) + delta, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            if (t == 5) {
                model = glm::scale(model, glm::vec3((1.0 + degree), 1.0, 1.0));
                model = glm::rotate(model, float(direction1 * 1.0f) + delta, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            model = glm::translate(model, glm::vec3(1.0 + ee, 1.0, 1.0));
            ee += 0.02;
            ourShader.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            select1 = 1;
        }
        if (choose != 1 and select1 == 1) {
            glBindVertexArray(VAO1);
            model = glm::mat4(1.0f);
            model = glm::scale(model, glm::vec3((1.0 + degree), 1.0, 1.0));
            model = glm::rotate(model, float(direction1 * 1.0f) + delta, glm::vec3(0.0f, 1.0f, 0.0f));
            ourShader.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }
        
        if (choose == 2) {
            glBindVertexArray(VAO2);
            model2 = glm::mat4(1.0f);
            model2 = change(window, choose);
            if (t == 0 or t == 3 and delta2 != 0) {
                model2 = glm::rotate(model2, float(direction2 * 1.0f) + delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            model2 = glm::translate(model2, cubePositions[0]);
            ourShader.setMat4("model", model2);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            select2 = 1;
        }
        if (choose != 2 and select2 == 1) {
            glBindVertexArray(VAO2);
            model2 = glm::mat4(1.0f);
            model2 = glm::rotate(model2, float(direction2 * 1.0f) + delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            model2 = glm::translate(model2, cubePositions[0]);
            ourShader.setMat4("model", model2);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }

        if (choose == 3) {
            glBindVertexArray(VAO3);
            model3 = glm::mat4(1.0f);
            model3 = change(window, choose);
            if (t == 0 or t == 3) {
                model3 = glm::rotate(model3, float(direction3 * 1.0f) + delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            }
            model3 = glm::translate(model3, prismPositins[0]);
            ourShader.setMat4("model", model3);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            select3 = 1;
        }
        if (choose != 3 and select3==1) {
            glBindVertexArray(VAO3);
            model3 = glm::mat4(1.0f);
            model3 = glm::rotate(model3, float(direction3 * 1.0f) + delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            model3 = glm::translate(model3, prismPositins[0]);
            ourShader.setMat4("model", model3);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO1);
    glDeleteBuffers(1, &VBO1);
    glDeleteVertexArrays(1, &VAO2);
    glDeleteBuffers(1, &VBO2);
    glDeleteVertexArrays(1, &VAO3);
    glDeleteBuffers(1, &VBO3);

    glfwTerminate();
    return 0;
}

void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    float cameraSpeed = 2.5 * deltaTime;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
        if (sign == 0)
            sign = 1;
        else
            sign = 0;

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        choose = 1;
    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS)
        choose = 2;
    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
        choose = 3;
    if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
        if (choose == 1)
            direction1 = 1;
        if (choose == 2)
            direction2 = 1;
        if (choose == 3)
            direction3 = 1;
    }
    if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
        if (choose == 1)
            direction1 = -1;
        if (choose == 2)
            direction2 = -1;
        if (choose == 3)
            direction3 = -1;
    }
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
        choose = 0;
    if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS)
    {
        if (choose == 1)
            dir1 = 1;
        if (choose == 2)
            dir2 = 1;
        if (choose == 3)
            dir3 = 1;
    }
    if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS) {
        if (choose == 1)
            dir1 = -1;
        if (choose == 2)
            dir2 = -1;
        if (choose == 3)
            dir3 = -1;
    }
}
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
    SCR_HEIGHT = height;
    SCR_WIDTH = width;
}
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    if (sign == 0) {
        yaw = yaw + xoffset;
        pitch = pitch + yoffset;
    }
    if (sign == 1) {
        yaw = yaw - xoffset;
        pitch = pitch - yoffset;
    }

    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 direction;
    direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    direction.y = sin(glm::radians(pitch));
    direction.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(direction);
}
glm::mat4 change(GLFWwindow* window, int choose) {
    glm::mat4 mod = glm::mat4(1.0f);
    if (choose == 1) {
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
            mod = glm::scale(mod, glm::vec3((1.0 + degree), 1.0, 1.0));
            mod = glm::rotate(mod, float(direction1 * 1.0f) + delta, glm::vec3(0.0f, 1.0f, 0.0f));
            delta = delta + direction1 * 0.002;
            t = 1;
        }
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_RELEASE and t == 1) {
            t = 0;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            mod = glm::scale(mod, glm::vec3((1.0 + degree), 1.0, 1.0));
            mod = glm::rotate(mod, float(direction1 * 1.0f) + delta, glm::vec3(0.0f, 1.0f, 0.0f));
            delta = delta + direction1 * 0.002;
            t = 2;
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_RELEASE and t == 2) {
            t = 3;
        }

        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) {
            mod = glm::scale(mod, glm::vec3((1.0 + degree), 1.0, 1.0));
            mod = glm::rotate(mod, float(direction1 * 1.0f) + delta, glm::vec3(0.0f, 1.0f, 0.0f));
            degree = degree + 0.0002;
            t = 4;
        }
        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_RELEASE and t == 4) {
            t = 5;
        }
    }
    if (choose == 2) {
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
            mod = glm::rotate(mod, float(direction2 * 1.0f) + delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            delta2 = delta2 + direction2 * 0.002;
            t = 1;
        }
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_RELEASE and t == 1) {
            t = 0;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            mod = glm::rotate(mod, float(direction2 * 1.0f) + delta2, glm::vec3(0.0f, 1.0f, 0.0f));
            delta2 = delta2 + direction2 * 0.002;
            t = 2;
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_RELEASE and t == 2) {
            t = 3;
        }

    }
    if (choose == 3) {
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {
            mod = glm::rotate(mod, float(direction3 * 1.0f) + delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            delta3 = delta3 + direction3 * 0.002;
            t = 1;
        }
        if (glfwGetKey(window, GLFW_KEY_H) == GLFW_RELEASE and t == 1) {
            t = 0;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            mod = glm::rotate(mod, float(direction3 * 1.0f) + delta3, glm::vec3(0.0f, 1.0f, 0.0f));
            delta3 = delta3 + direction3 * 0.002;
            t = 2;
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_RELEASE and t == 2) {
            t = 3;
        }

    }

    
    return mod;

}
